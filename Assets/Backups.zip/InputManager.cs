﻿using UnityEngine;
using System.Collections;

public static class InputManager {
    public static float GetAxis(InputDevice device, InputAxis axis) {
        return Input.GetAxisRaw(ToInputString(device, axis));
    }

    public static bool GetButton(InputDevice device, InputAxis axis) {
        //Debug.Log(device + "|" + axis);

        string input = ToInputString(device, axis);

        switch (axis.GetInputType()) {
            case InputType.AxisBoth:
                return Input.GetAxisRaw(input) != 0;
            case InputType.AxisController: 
                if (device == InputDevice.Keyboard) {
                    return Input.GetButton(input);
                }

                return Input.GetAxisRaw(input) != 0;
            case InputType.AxisKeyboard:
                if (device == InputDevice.Keyboard) {
                    return Input.GetAxisRaw(input) != 0;
                }

                return Input.GetButton(input);
            default:
                return Input.GetButton(input);
        }
    }

    public static bool GetButtonDown(InputDevice device, InputAxis axis) {
        //Debug.Log(device + "|" + axis);

        string input = ToInputString(device, axis);

        switch (axis.GetInputType()) {
            case InputType.AxisBoth:
                return Input.GetAxisRaw(input) != 0;
            case InputType.AxisController:
                if (device == InputDevice.Keyboard) {
                    return Input.GetButtonDown(input);
                }

                return Input.GetAxisRaw(input) != 0;
            case InputType.AxisKeyboard:
                if (device == InputDevice.Keyboard) {
                    return Input.GetAxisRaw(input) != 0;
                }

                return Input.GetButtonDown(input);
            default:
                return Input.GetButtonDown(input);
        }
    }

    private static string ToInputString(InputDevice device, InputAxis axis) {
        switch (device) {
            case InputDevice.Keyboard:
                return "Keyboard " + axis.ToString();
            default:
                return "Joystick " + (int)device + " " + axis.ToString();
        }
    }

    public enum InputType {
        AxisBoth,
        AxisController,
        AxisKeyboard,
        ButtonBoth
    }
}

public enum InputDevice : int {
    Keyboard = -1,
    AnyController = 0,
    Controller1 = 1,
    Controller2 = 2,
    Controller3 = 3,
    Controller4 = 4
}

public enum InputAxis {
    Horizontal,
    Vertical,
    HorizontalLook,
    VerticalLook,
    Trigger,
    Accept,
    Deny,
    Left,
    Right,
    Back,
    Start,
    Ability1,
    Ability2,
    Ability3,
    Ability4
}

public static class InputAxisExtension {
    public static InputManager.InputType GetInputType(this InputAxis inputAxis) {
        switch (inputAxis) {
            case InputAxis.Trigger:
            case InputAxis.Ability1:
            case InputAxis.Ability2:
            case InputAxis.Ability3:
            case InputAxis.Ability4:
                return InputManager.InputType.AxisController;
            case InputAxis.Horizontal:
            case InputAxis.Vertical:
            case InputAxis.HorizontalLook:
            case InputAxis.VerticalLook:
                return InputManager.InputType.AxisBoth;
            default:
                return InputManager.InputType.ButtonBoth;
        }
    }
}