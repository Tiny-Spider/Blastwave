﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameCamera : MonoBehaviour {
    public float smoothing = 8;

    private List<Transform> targetTransforms = new List<Transform>();
    private Vector3 targetPosition = Vector3.zero;
    
    // Fov
    private const float FOV_MARGIN = 15.0f;
    private float aspectRatio;

    void Start() {
        aspectRatio = Screen.width / Screen.height;
    }
    // End Fov

    void FixedUpdate() {
        // Temp fix
        for (var i = targetTransforms.Count - 1; i >= 0; i--) {
            if (targetTransforms[i] == null) {
                targetTransforms.RemoveAt(i);
            }
        }

        CalculateCenter();
        CalculateFov();

        float deltaTime = Time.deltaTime * smoothing;
        transform.position = Vector3.Lerp(transform.position, targetPosition, deltaTime);
    }

    public void SetTargets(IEnumerable<Player> players) {
        foreach (Player player in players) {
            targetTransforms.Add(player.transform);
        }
    }

    void CalculateCenter() {
        targetPosition = Vector3.zero;

        if (targetTransforms.Count > 0) {
            int numPoints = 0;

            foreach (Transform transform in targetTransforms) {
                if (transform) {
                    targetPosition += transform.position;
                    numPoints++;
                }
            }

            if (numPoints > 0) {
                targetPosition /= numPoints;
            }
        }
    }

    void CalculateFov() {
        if (targetTransforms.Count > 0) {
            // Calculate the new FOV.
            float distanceBetweenPlayers = ((targetTransforms[0].position - targetPosition) * 2f).magnitude;
            //float distanceFromMiddlePoint = (Camera.main.transform.position - targetPosition).magnitude;
            Camera.main.fieldOfView = 2.0f * Mathf.Rad2Deg * Mathf.Atan((0.5f * distanceBetweenPlayers) / (targetPosition.magnitude * aspectRatio));

            // Add small margin so the players are not on the viewport border.
            Camera.main.fieldOfView += FOV_MARGIN;
            Camera.main.fieldOfView = Mathf.Max(90f, Camera.main.fieldOfView);
        }
    }
}